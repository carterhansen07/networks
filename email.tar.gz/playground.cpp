
#include <stdio.h>
#include <iostream> 
#include <iomanip>
#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>







void copyarray(unsigned char * destarray, unsigned char * arraytocopy, unsigned int length )
{
  for (unsigned int i =0; i < length; i++ )
  {
  		destarray[i] = arraytocopy[i];

  }
}


int main(){
unsigned char my_mac[8];
unsigned char temp;
unsigned char place = 0xa0;
printf ("a0 is %d\n", place);
unsigned char useless;
std::ifstream addressfile;
addressfile.open("/sys/class/net/eno1/address");

for (unsigned int i = 0; i<6; i++)
{

addressfile >> my_mac[i];
addressfile >> temp;
printf("we just read in: %c for the first and %c for the 2nd\n", my_mac[i],temp);

my_mac[i] = (my_mac[i]>= 'a')?(my_mac[i]-'a'+10) : (my_mac[i] - '0');
my_mac[i] = my_mac[i] <<4;

temp = (temp>= 'a')?(temp-'a'+10) : (temp - '0');
temp = temp;


printf("%d \n", my_mac[i]);
printf("temp %d \n", temp);

my_mac[i] = temp + my_mac[i];
printf("New mac %02x \n", my_mac[i]);

addressfile >> useless;

}



unsigned char x[4];
unsigned char y[8];
x[0] = 2;
x[1] = 2;
x[2] = 2;
x[3] = 2;



y[0] = 1;
y[1] = 1;
y[2] = 1;
y[3] = 1;
y[4] = 5;
y[5] = 5;
y[6] = 5;
y[7] = 5;


copyarray((y+4),x,4);


for (unsigned int i = 0; i < 8; i++)
	{
		printf("array y at %d is: %d \n",i, y[i]);


	}





return 0;


}
